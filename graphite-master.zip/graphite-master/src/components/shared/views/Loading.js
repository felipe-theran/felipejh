import React, { Component } from 'reactn';

class Loading extends Component {
  render() {
      return (
        <div>
         Loading
        </div>
       );
  }
}

export default Loading;
