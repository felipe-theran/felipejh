import React, { Component } from 'reactn';

class SingleFormResults extends Component {
  render() {
      return (
        <div>
         Single Form Results
        </div>
       );
  }
}

export default SingleFormResults;
