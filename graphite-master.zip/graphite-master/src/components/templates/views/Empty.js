import React, { Component } from 'reactn';

class EmptyComponent extends Component {
  render() {
      return (
        <div>
         Empty Component
        </div>
       );
  }
}

export default EmptyComponent;
